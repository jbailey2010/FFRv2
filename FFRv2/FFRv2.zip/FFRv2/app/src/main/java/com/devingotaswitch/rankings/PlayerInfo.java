package com.devingotaswitch.rankings;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.adroitandroid.chipcloud.ChipCloud;
import com.adroitandroid.chipcloud.ChipListener;
import com.amazonaws.util.StringUtils;
import com.andrognito.flashbar.Flashbar;
import com.devingotaswitch.appsync.AppSyncHelper;
import com.devingotaswitch.ffrv2.R;
import com.devingotaswitch.fileio.LocalSettingsHelper;
import com.devingotaswitch.fileio.RankingsDBWrapper;
import com.devingotaswitch.rankings.domain.DailyProjection;
import com.devingotaswitch.rankings.domain.Player;
import com.devingotaswitch.rankings.domain.PlayerNews;
import com.devingotaswitch.rankings.domain.Rankings;
import com.devingotaswitch.rankings.domain.Team;
import com.devingotaswitch.rankings.domain.appsync.comments.Comment;
import com.devingotaswitch.rankings.domain.appsync.tags.Tag;
import com.devingotaswitch.rankings.extras.CommentAdapter;
import com.devingotaswitch.rankings.extras.PlayerInfoSwipeDetector;
import com.devingotaswitch.rankings.sources.ParseMath;
import com.devingotaswitch.rankings.sources.ParsePlayerNews;
import com.devingotaswitch.utils.Constants;
import com.devingotaswitch.utils.DraftUtils;
import com.devingotaswitch.utils.FlashbarFactory;
import com.devingotaswitch.utils.GeneralUtils;
import com.devingotaswitch.utils.GraphUtils;
import com.devingotaswitch.youruserpools.CUPHelper;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.DefaultAxisValueFormatter;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class PlayerInfo extends AppCompatActivity {
    private static final String TAG = "PlayerInfo";

    private Rankings rankings;
    private Player player;
    private List<PlayerNews> playerNews;
    private RankingsDBWrapper rankingsDB;

    private int viewCount = -1;
    private int watchCount= -1;
    private int draftCount = -1;
    private List<String> userTags = new ArrayList<>();
    private boolean sortByUpvotes = false;
    private boolean doUpdateImage = false;
    private String replyId = Constants.COMMENT_NO_REPLY_ID;
    private int replyDepth = 0;

    private List<Map<String, String>> data;
    private SimpleAdapter adapter;
    private List<Map<String, String>> commentData;
    private CommentAdapter commentAdapter;
    private ListView infoList;
    private ListView commentList;
    private MenuItem addWatch;
    private MenuItem removeWatch;
    private MenuItem draftMe;
    private MenuItem draftOther;
    private MenuItem undraft;
    private MenuItem commentSortDate;
    private MenuItem commentSortTop;
    private ChipCloud chipCloud;

    private static String playerId;

    private static final Integer MAX_NEARBY_PLAYERS = 6;

    private List<Comment> comments = new ArrayList<>();
    private Map<String, List<Comment>> replyMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_info);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        rankingsDB = new RankingsDBWrapper();
        rankings = Rankings.init();
        playerId = getIntent().getStringExtra(Constants.PLAYER_ID);
        Player mostlyFleshedPlayer = rankings.getPlayer(playerId);
        player = rankingsDB.getPlayer(this, mostlyFleshedPlayer.getName(), mostlyFleshedPlayer.getTeamName(), mostlyFleshedPlayer.getPosition());

        // Set toolbar for this screen
        Toolbar toolbar = findViewById(R.id.toolbar_player_info);
        toolbar.setTitle("");
        TextView main_title = findViewById(R.id.main_toolbar_title);
        main_title.setText(player.getName());
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        final Activity activity = this;
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GeneralUtils.hideKeyboard(activity);
                onBackPressed();
            }
        });

        sortByUpvotes = Constants.COMMENT_SORT_TOP.equals(LocalSettingsHelper.getCommentSortType(this));

        // Kick off the thread to get news
        ParsePlayerNews.startNews(player.getName(), player.getTeamName(), this);

        // Kick off the thread to get comments
        AppSyncHelper.getCommentsForPlayer(this, player.getUniqueId(), null, sortByUpvotes);

        // Kick off the thread to get player metadata
        AppSyncHelper.getOrCreatePlayerMetadataAndIncrementViewCount(this, player.getUniqueId());
    }

    @Override
    public void onResume() {
        super.onResume();

        Player mostlyFleshedPlayer = rankings.getPlayer(playerId);
        player = rankingsDB.getPlayer(this, mostlyFleshedPlayer.getName(), mostlyFleshedPlayer.getTeamName(), mostlyFleshedPlayer.getPosition());

        try {
            init();
        } catch (Exception e) {
            Log.d(TAG, "Failure setting up activity, falling back to Rankings", e);
            GeneralUtils.hideKeyboard(this);
            onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_player_info_menu, menu);
        addWatch = menu.findItem(R.id.player_info_add_watched);
        removeWatch = menu.findItem(R.id.player_info_remove_watched);
        draftMe = menu.findItem(R.id.player_info_draft_me);
        draftOther = menu.findItem(R.id.player_info_draft_someone);
        undraft = menu.findItem(R.id.player_info_undraft);
        commentSortDate = menu.findItem(R.id.player_info_sort_comments_date);
        commentSortTop = menu.findItem(R.id.player_info_sort_comments_top);
        hideMenuItemOnWatchStatus();
        hideMenuItemsOnDraftStatus();
        hideMenuItemsOnCommentSort();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Find which menu item was selected
        int menuItem = item.getItemId();
        switch(menuItem) {
            case R.id.player_info_add_watched:
                addWatched();
                return true;
            case R.id.player_info_remove_watched:
                removeWatched();
                return true;
            case R.id.player_info_draft_me:
                if (rankings.getLeagueSettings().isAuction()) {
                    getAuctionCost();
                } else {
                    draftByMe(0);
                }
                return true;
            case R.id.player_info_draft_someone:
                draftBySomeone();
                return true;
            case R.id.player_info_undraft:
                undraftPlayer();
                return true;
            case R.id.player_info_compare:
                comparePlayer();
                return true;
            case R.id.player_info_simulate_adp:
                simulateAdp();
                return true;
            case R.id.player_info_sort_comments_date:
                sortCommentsByDate();
                return true;
            case R.id.player_info_sort_comments_top:
                sortCommentsByUpvotes();
                return true;
            case R.id.player_info_projection_history:
                showProjectionHistory();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }

    private void addWatched() {
        final Flashbar.OnActionTapListener removeWatch = new Flashbar.OnActionTapListener() {
            @Override
            public void onActionTapped(Flashbar flashbar) {
                flashbar.dismiss();
                removeWatched();
            }
        };
        FlashbarFactory.generateFlashbarWithUndo(this, "Success!", player.getName() + " added to watch list",
                Flashbar.Gravity.BOTTOM, removeWatch)
                .show();
        rankings.togglePlayerWatched(this, player.getUniqueId());
        conditionallyUpdatePlayerStatus();
        hideMenuItemOnWatchStatus();
    }

    private void removeWatched() {
        final Flashbar.OnActionTapListener addWatch = new Flashbar.OnActionTapListener() {
            @Override
            public void onActionTapped(Flashbar flashbar) {
                flashbar.dismiss();
                addWatched();
            }
        };
        FlashbarFactory.generateFlashbarWithUndo(this, "Success!", player.getName() + " removed from watch list",
                Flashbar.Gravity.BOTTOM, addWatch)
                .show();
        rankings.togglePlayerWatched(this, player.getUniqueId());
        hideMenuItemOnWatchStatus();
        conditionallyUpdatePlayerStatus();
    }

    public void swipeLeftToRight() {
        if (View.VISIBLE == findViewById(R.id.ranks_button_selected).getVisibility()) {
            displayComments();
        } else if (View.VISIBLE == findViewById(R.id.player_info_button_selected).getVisibility()) {
            displayRanks();
        } else if (View.VISIBLE == findViewById(R.id.team_info_button_selected).getVisibility()) {
            displayInfo();
        } else if (View.VISIBLE == findViewById(R.id.news_button_selected).getVisibility()) {
            displayTeam();
        } else if (View.VISIBLE == findViewById(R.id.comment_button_selected).getVisibility()) {
            displayNews();
        }
    }

    public void swipeRightToLeft() {
        if (View.VISIBLE == findViewById(R.id.ranks_button_selected).getVisibility()) {
            displayInfo();
        } else if (View.VISIBLE == findViewById(R.id.player_info_button_selected).getVisibility()) {
            displayTeam();
        } else if (View.VISIBLE == findViewById(R.id.team_info_button_selected).getVisibility()) {
            displayNews();
        } else if (View.VISIBLE == findViewById(R.id.news_button_selected).getVisibility()) {
            displayComments();
        } else if (View.VISIBLE == findViewById(R.id.comment_button_selected).getVisibility()) {
            displayRanks();
        }
    }

    private void hideMenuItemOnWatchStatus() {
        if (rankings.isPlayerWatched(player.getUniqueId())) {
            addWatch.setVisible(false);
            removeWatch.setVisible(true);
        } else {
            addWatch.setVisible(true);
            removeWatch.setVisible(false);
        }
    }

    private void sortCommentsByDate() {
        comments.clear();
        replyMap.clear();
        commentData.clear();
        sortByUpvotes = false;
        AppSyncHelper.getCommentsForPlayer(this, player.getUniqueId(), null, sortByUpvotes);
        LocalSettingsHelper.saveCommentSortType(this, Constants.COMMENT_SORT_DATE);
        hideMenuItemsOnCommentSort();
    }

    private void sortCommentsByUpvotes() {
        comments.clear();
        replyMap.clear();
        commentData.clear();
        sortByUpvotes = true;
        AppSyncHelper.getCommentsForPlayer(this, player.getUniqueId(), null, true);
        LocalSettingsHelper.saveCommentSortType(this, Constants.COMMENT_SORT_TOP);
        hideMenuItemsOnCommentSort();
    }

    private void showProjectionHistory() {
        LayoutInflater li = LayoutInflater.from(this);
        View graphView = li.inflate(R.layout.sort_graph_popup, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);

        alertDialogBuilder.setView(graphView);
        LineChart lineGraph =  graphView.findViewById(R.id.sort_graph);

        List<Entry> projectionDays = new ArrayList<>();
        List<DailyProjection> projections = rankings.getPlayerProjectionHistory().get(player.getUniqueId());
        if (projections != null) {
            for (int i = 0; i < projections.size(); i++) {
                DailyProjection projection = projections.get(i);
                projectionDays.add(new Entry((float) i, (float) projection.getProjection(rankings.getLeagueSettings().getScoringSettings())));
            }
        } else {
            // If a league scoring setting change was made, the data will clear, so we'll just take the current projection.
            projectionDays.add(new Entry(1f, player.getProjection().floatValue()));
        }
        LineDataSet projectionHistoryDataset = GraphUtils.getLineDataSet(projectionDays,
                player.getName() + " Projections", "blue");
        projectionHistoryDataset.setFillColor(Color.BLUE);
        if (projectionDays.size() == 1) {
            projectionHistoryDataset.setDrawCircles(true);
        }
        LineData lineData = new LineData();
        lineData.addDataSet(projectionHistoryDataset);

        lineGraph.setData(lineData);
        lineGraph.setDrawBorders(true);
        lineGraph.setNoDataText("No projections are available for " + player.getName());
        Description description = new Description();
        description.setText("");
        lineGraph.setDescription(description);
        lineGraph.invalidate();
        lineGraph.setTouchEnabled(true);
        lineGraph.setPinchZoom(true);
        lineGraph.setDragEnabled(true);
        lineGraph.animateX(1500);
        lineGraph.animateY(1500);

        XAxis x = lineGraph.getXAxis();
        x.setPosition(XAxis.XAxisPosition.BOTTOM);
        x.setDrawAxisLine(false);
        x.setDrawLabels(false);
        x.setDrawGridLines(false);

        YAxis yR = lineGraph.getAxisRight();
        yR.setDrawAxisLine(false);
        yR.setDrawGridLines(false);
        yR.setDrawLabels(false);

        YAxis yL = lineGraph.getAxisLeft();
        yL.setDrawLabels(true);
        yL.setDrawGridLines(true);
        yL.setDrawAxisLine(false);

        alertDialogBuilder
                .setNegativeButton("Dismiss",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                dialog.cancel();
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void hideMenuItemsOnCommentSort() {
        if (sortByUpvotes) {
            commentSortDate.setVisible(true);
            commentSortTop.setVisible(false);
        } else {
            commentSortDate.setVisible(false);
            commentSortTop.setVisible(true);
        }
    }

    private void getAuctionCost() {
        final Activity localCopy = this;
        DraftUtils.AuctionCostInterface callback = new DraftUtils.AuctionCostInterface() {
            @Override
            public void onValidInput(Integer cost) {
                draftByMe(cost);
            }

            @Override
            public void onInvalidInput() {
                FlashbarFactory.generateTextOnlyFlashbar(localCopy, "No can do", "Must provide a number for cost",
                    Flashbar.Gravity.TOP)
                    .show();
            }

            @Override
            public void onCancel() {

            }
        };
        AlertDialog alertDialog = DraftUtils.getAuctionCostDialog(this, player, callback);
        alertDialog.show();
    }

    private void draftByMe(int cost) {
        Flashbar.OnActionTapListener listener = new Flashbar.OnActionTapListener() {
            @Override
            public void onActionTapped(Flashbar flashbar) {
                undraftPlayer();
            }
        };
        rankings.getDraft().draftByMe(rankings, player, this, cost, infoList, listener);
        hideMenuItemsOnDraftStatus();
        displayRanks();
    }

    private void draftBySomeone() {
        Flashbar.OnActionTapListener listener = new Flashbar.OnActionTapListener() {
            @Override
            public void onActionTapped(Flashbar flashbar) {
                undraftPlayer();
            }
        };
        rankings.getDraft().draftBySomeone(rankings, player, this, infoList, listener);
        hideMenuItemsOnDraftStatus();
        displayRanks();
    }

    private void undraftPlayer() {
        rankings.getDraft().undraft(rankings, player, this, infoList);
        hideMenuItemsOnDraftStatus();
        conditionallyUpdatePlayerStatus();
    }

    private void conditionallyUpdatePlayerStatus() {
        if (View.VISIBLE == chipCloud.getVisibility()) {
            displayInfo();
        }
    }

    private void comparePlayer() {
        Intent intent = new Intent(this, PlayerComparator.class);
        intent.putExtra(Constants.PLAYER_ID, player.getUniqueId());
        startActivity(intent);
    }

    private void simulateAdp() {
        Intent intent = new Intent(this, ADPSimulator.class);
        intent.putExtra(Constants.PLAYER_ID, player.getUniqueId());
        startActivity(intent);
    }

    private void hideMenuItemsOnDraftStatus() {
        if (rankings.getDraft().isDrafted(player)) {
            draftMe.setVisible(false);
            draftOther.setVisible(false);
            undraft.setVisible(true);
        } else {
            draftMe.setVisible(true);
            draftOther.setVisible(true);
            undraft.setVisible(false);
        }
    }

    private void init() {
        Button headerLeft = findViewById(R.id.dummy_btn_left);
        Button headerRight = findViewById(R.id.dummy_btn_right);
        Button headerMiddle = findViewById(R.id.dummy_btn_center);
        if (player.getAge() != null && player.getAge() > 0 && !Constants.DST.equals(player.getPosition()))  {
            StringBuilder expBuilder = new StringBuilder()
                    .append("Age: ")
                    .append(player.getAge());
            if (player.getExperience() >= 0) {
                expBuilder.append(Constants.LINE_BREAK)
                        .append("Exp: ")
                        .append(player.getExperience());
            }
            headerLeft.setText(expBuilder.toString());
        } else if (Constants.DST.equals(player.getPosition())) {
            headerLeft.setText("Age: N/A");
        }
        if (rankings.getTeam(player) != null && !"0".equals(rankings.getTeam(player).getBye())) {
            headerRight.setText("Bye:" + Constants.LINE_BREAK + rankings.getTeam(player).getBye());
        } else if ("0".equals(rankings.getTeam(player).getBye())) {
            headerRight.setText("Bye: N/A");
        }
        headerMiddle.setText(player.getTeamName() + Constants.LINE_BREAK + player.getPosition());

        infoList = findViewById(R.id.player_info_list);
        commentList = findViewById(R.id.player_info_comment_list);
        data = new ArrayList<>();
        commentData = new ArrayList<>();
        adapter = new SimpleAdapter(this, data,
                R.layout.list_item_player_info_layout,
                new String[] { Constants.PLAYER_BASIC, Constants.PLAYER_INFO},
                new int[] { R.id.player_basic, R.id.player_info});
        commentAdapter = new CommentAdapter(this, commentData,
                R.layout.list_item_comment_layout,
                new String[] {Constants.COMMENT_AUTHOR, Constants.COMMENT_CONTENT, Constants.COMMENT_TIMESTAMP, Constants.COMMENT_ID,
                    Constants.COMMENT_REPLY_ID, Constants.COMMENT_REPLY_DEPTH, Constants.COMMENT_UPVOTE_IMAGE, Constants.COMMENT_UPVOTE_COUNT,
                    Constants.COMMENT_DOWNVOTE_IMAGE, Constants.COMMENT_DOWNVOTE_COUNT},
                new int[] { R.id.comment_author, R.id.comment_content, R.id.comment_timestamp, R.id.comment_id, R.id.comment_reply_id,
                    R.id.comment_reply_depth, R.id.comment_upvoted_icon, R.id.comment_upvote_count, R.id.comment_downvoted_icon,
                    R.id.comment_downvote_count});
        infoList.setAdapter(adapter);
        commentList.setAdapter(commentAdapter);
        PlayerInfoSwipeDetector detector = new PlayerInfoSwipeDetector(this);
        infoList.setOnTouchListener(detector);
        commentList.setOnTouchListener(detector);
        RelativeLayout footerView = (RelativeLayout)LayoutInflater.from(this).inflate(R.layout.tag_footer_view, null);
        chipCloud = footerView.findViewById(R.id.chip_cloud);
        infoList.addFooterView(footerView);

        ImageButton ranks = findViewById(R.id.player_info_ranks);
        ImageButton info =  findViewById(R.id.player_info_about);
        ImageButton team =  findViewById(R.id.player_info_team);
        ImageButton news =  findViewById(R.id.player_info_news);
        ImageButton comments = findViewById(R.id.player_info_comments);
        ranks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayRanks();
            }
        });
        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayInfo();
            }
        });
        team.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayTeam();
            }
        });
        news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayNews();
            }
        });
        comments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displayComments();
            }
        });

        infoList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView subView = view.findViewById(R.id.player_info);
                if (Constants.NOTE_SUB.equals(subView.getText().toString())) {
                    String existing = ((TextView)view.findViewById(R.id.player_basic)).getText().toString();
                    getNote(existing);
                }
            }
        });
        infoList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                TextView subView = view.findViewById(R.id.player_info);
                if (Constants.NOTE_SUB.equals(subView.getText().toString())) {
                    setNoteAndDisplayIt("");
                }
                return true;
            }
        });
        commentList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                String author = ((TextView)view.findViewById(R.id.comment_author)).getText().toString();
                if (CUPHelper.getCurrUser().equals(author)) {
                    String id = ((TextView)view.findViewById(R.id.comment_id)).getText().toString();
                    confirmCommentDeletion(id);
                }
                return true;
            }
        });

        displayRanks();
    }

    public void setAggregatePlayerMetadata(int viewCount, int watchCount, int draftCount, List<Tag> tags,
                                           List<String> userTags) {
        this.watchCount = watchCount;
        this.viewCount = viewCount;
        this.draftCount = draftCount;
        this.userTags = userTags;

        setTags(tags);
    }

    public void setTags(final List<Tag> tags) {
        String[] tagArr = new String[tags.size()];
        List<Integer> taggedIndices = new ArrayList<>();
        for (int i = 0; i < tags.size(); i++) {
            Tag tag = tags.get(i);
            tagArr[i] = tag.getTagText();
            if (userTags.contains(tag.getTitle())) {
                taggedIndices.add(i);
            }
        }
        final Activity activity = this;

        new ChipCloud.Configure()
                .chipCloud(chipCloud)
                .selectedColor(Color.parseColor("#329AD6"))
                .selectedFontColor(Color.parseColor("#ffffff"))
                .deselectedColor(Color.parseColor("#f1f1f1"))
                .deselectedFontColor(Color.parseColor("#333333"))
                .selectTransitionMS(0)
                .deselectTransitionMS(250)
                .labels(tagArr)
                .mode(ChipCloud.Mode.MULTI)
                .allCaps(false)
                .gravity(ChipCloud.Gravity.STAGGERED)
                .textSize(getResources().getDimensionPixelSize(R.dimen.default_textsize))
                .verticalSpacing(getResources().getDimensionPixelSize(R.dimen.vertical_spacing))
                .minHorizontalSpacing(getResources().getDimensionPixelSize(R.dimen.min_horizontal_spacing))
                .chipListener(new ChipListener() {
                    @Override
                    public void chipSelected(int index) {
                        Tag tag = tags.get(index);
                        String text = tag.getTitle();
                        if (!userTags.contains(text)) {
                            userTags.add(text);
                            AppSyncHelper.incrementTagCount(activity, playerId, tag, userTags);
                        }
                    }
                    @Override
                    public void chipDeselected(int index) {
                        Tag tag = tags.get(index);
                        String text = tag.getTitle();
                        if (userTags.contains(text)) {
                            userTags.remove(text);
                            AppSyncHelper.decrementTagCount(activity, playerId, tag, userTags);
                        }
                    }
                })
                .build();

        for (Integer index : taggedIndices) {
            chipCloud.setSelectedChip(index);
        }
    }

    private void confirmCommentDeletion(final String commentId) {
        LayoutInflater li = LayoutInflater.from(this);
        View noteView = li.inflate(R.layout.user_input_popup, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);

        alertDialogBuilder.setView(noteView);
        final EditText userInput = noteView
                .findViewById(R.id.user_input_popup_input);
        userInput.setVisibility(View.GONE);

        TextView title = noteView.findViewById(R.id.user_input_popup_title);
        title.setText("Are you sure you want to delete this comment?");
        final Activity activity = this;
        alertDialogBuilder
                .setPositiveButton("Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                AppSyncHelper.deleteComment(activity, commentId);
                                hideComment(commentId);
                            }
                        })
                .setNegativeButton("No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                dialog.cancel();
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void hideComment(String commentId) {
        for (Map<String, String> datum : commentData) {
            if (datum.get(Constants.COMMENT_ID).equals(commentId)) {
                commentData.remove(datum);
                commentAdapter.notifyDataSetChanged();
                break;
            }
        }
        Iterator<Comment> iterator = comments.iterator();
        while (iterator.hasNext()) {
            if (iterator.next().getId().equals(commentId)) {
                iterator.remove();
            }
        }

        if (commentData.size() == 0) {
            displayComments();
        }
    }

    private void getNote(String existing) {
        LayoutInflater li = LayoutInflater.from(this);
        View noteView = li.inflate(R.layout.user_input_popup, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                this);

        alertDialogBuilder.setView(noteView);
        final EditText userInput = noteView
                .findViewById(R.id.user_input_popup_input);
        userInput.setHint("Player note");
        if (!Constants.DEFAULT_NOTE.equals(existing)) {
            userInput.setText(existing);
        }

        TextView title = noteView.findViewById(R.id.user_input_popup_title);
        title.setText("Input a note for " + player.getName());
        final Activity localCopy = this;
        alertDialogBuilder
                .setPositiveButton("Save",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                String newNote = userInput.getText().toString();
                                if (StringUtils.isBlank(newNote)) {
                                    FlashbarFactory.generateTextOnlyFlashbar(localCopy, "No can do", "No note given",
                                        Flashbar.Gravity.TOP)
                                        .show();
                                } else {
                                    setNoteAndDisplayIt(newNote);
                                    dialog.dismiss();
                                }
                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                dialog.cancel();
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void setNoteAndDisplayIt(String newNote) {
        rankings.updatePlayerNote(this, player.getUniqueId(), newNote);
        displayInfo();
    }

    private void displayRanks() {
        data.clear();
        commentData.clear();
        commentList.setVisibility(View.GONE);
        infoList.setVisibility(View.VISIBLE);
        chipCloud.setVisibility(View.GONE);

        View ranks = findViewById(R.id.ranks_button_selected);
        View playerSelected = findViewById(R.id.player_info_button_selected);
        View team = findViewById(R.id.team_info_button_selected);
        View news = findViewById(R.id.news_button_selected);
        View comments = findViewById(R.id.comment_button_selected);
        findViewById(R.id.comment_input_base).setVisibility(View.GONE);
        ranks.setVisibility(View.VISIBLE);
        playerSelected.setVisibility(View.INVISIBLE);
        team.setVisibility(View.INVISIBLE);
        news.setVisibility(View.INVISIBLE);
        comments.setVisibility(View.INVISIBLE);

        Map<String, String> ecr = new HashMap<>();
        ecr.put(Constants.PLAYER_BASIC, "ECR: " + (player.getEcr().equals(Constants.DEFAULT_RANK) ? Constants.DEFAULT_DISPLAY_RANK_NOT_SET : player.getEcr()));
        if (!player.getEcr().equals(Constants.DEFAULT_RANK)) {
            int ecrRank = getEcr(null, player.getEcr());
            int ecrRankPos = getEcr(player.getPosition(), player.getEcr());
            String ecrSub = getRankingSub(ecrRank, ecrRankPos);
            if (player.getRisk() != null && (rankings.getLeagueSettings().isAuction() || rankings.getLeagueSettings().isSnake())) {
                ecrSub += Constants.LINE_BREAK + "Risk: " + player.getRisk();
            }
            ecr.put(Constants.PLAYER_INFO, ecrSub);
        }
        data.add(ecr);

        Map<String, String> adp = new HashMap<>();
        adp.put(Constants.PLAYER_BASIC, "ADP: " + (player.getAdp().equals(Constants.DEFAULT_RANK) ? Constants.DEFAULT_DISPLAY_RANK_NOT_SET : player.getAdp()));
        StringBuilder adpSub = new StringBuilder();
        if (!player.getAdp().equals(Constants.DEFAULT_RANK)) {
            int adpRank = getAdp(null, player.getAdp());
            int adpPos = getAdp(player.getPosition(), player.getAdp());
            adpSub = new StringBuilder(getRankingSub(adpRank, adpPos));

        }
        int draftedPlayers = rankings.getDraft().getDraftedPlayers().size();
        if (draftedPlayers > 0) {
            if (adpSub.length() > 0) {
                adpSub.append(Constants.LINE_BREAK);
            }
            adpSub.append("Current draft position: ")
                    .append(draftedPlayers + 1);
        }
        adp.put(Constants.PLAYER_INFO, adpSub.toString());
        data.add(adp);

        Map<String, String> auc = new HashMap<>();
        auc.put(Constants.PLAYER_BASIC, "Auction Value: $" + Constants.DECIMAL_FORMAT.format(player.getAuctionValueCustom(rankings)));
        int aucRank = getAuc(null, player.getAuctionValue());
        int aucPos = getAuc(player.getPosition(), player.getAuctionValue());
        String auctionSub = getRankingSub(aucRank, aucPos) +
                Constants.LINE_BREAK +
                getLeverage();
        auc.put(Constants.PLAYER_INFO, auctionSub);
        data.add(auc);

        Map<String, String> dynasty = new HashMap<>();
        dynasty.put(Constants.PLAYER_BASIC, "Dynasty/Keeper Ranking: " + (player.getDynastyRank().equals(Constants.DEFAULT_RANK) ? Constants.DEFAULT_DISPLAY_RANK_NOT_SET : player.getDynastyRank()));
        if (!player.getDynastyRank().equals(Constants.DEFAULT_RANK)) {
            int dynRank = getDynasty(null, player.getDynastyRank());
            int dynRankPos = getDynasty(player.getPosition(), player.getDynastyRank());
            String dynSub = getRankingSub(dynRank, dynRankPos);

            if (player.getRisk() != null && rankings.getLeagueSettings().isDynasty()) {
                dynSub += Constants.LINE_BREAK + "Risk: " + player.getRisk();
            }
            dynasty.put(Constants.PLAYER_INFO, dynSub);
        }
        data.add(dynasty);

        if (!player.getRookieRank().equals(Constants.DEFAULT_RANK)) {
            // 300.0 is the default, so this is basically 'is it set?'
            Map<String, String> rookie = new HashMap<>();
            rookie.put(Constants.PLAYER_BASIC, "Rookie Rankings: " + player.getRookieRank());
            int rookieRank = getRookie(null, player.getRookieRank());
            int rookieRankPos = getRookie(player.getPosition(), player.getRookieRank());
            String rookieSub = getRankingSub(rookieRank, rookieRankPos);

            if (player.getRisk() != null && rankings.getLeagueSettings().isRookie()) {
                rookieSub += Constants.LINE_BREAK + "Risk: " + player.getRisk();
            }
            rookie.put(Constants.PLAYER_INFO, rookieSub);
            data.add(rookie);
        }

        Map<String, String> bestBall = new HashMap<>();
        bestBall.put(Constants.PLAYER_BASIC, "Best Ball Ranking: " + (player.getBestBallRank().equals(Constants.DEFAULT_RANK) ? Constants.DEFAULT_DISPLAY_RANK_NOT_SET : player.getBestBallRank()));
        if (!player.getBestBallRank().equals(Constants.DEFAULT_RANK)) {
            int bbRank = getBestBall(null, player.getBestBallRank());
            int bbRankPos = getBestBall(player.getPosition(), player.getBestBallRank());
            String bbSub = getRankingSub(bbRank, bbRankPos);

            if (player.getRisk() != null && rankings.getLeagueSettings().isBestBall()) {
                bbSub += Constants.LINE_BREAK + "Risk: " + player.getRisk();
            }
            bestBall.put(Constants.PLAYER_INFO, bbSub);
        }
        data.add(bestBall);

        if (player.getProjection() != null) {
            Map<String, String> proj = new HashMap<>();
            proj.put(Constants.PLAYER_BASIC, "Projection: " + player.getProjection());
            int projRank = getProj(null, player.getProjection());
            int projPos = getProj(player.getPosition(), player.getProjection());
            String projectionBreakdown = player.getPlayerProjection().getDisplayString(player.getPosition());
            String rankingSub = new StringBuilder()
                    .append(getRankingSub(projRank, projPos))
                    .append(projectionBreakdown.length() > 0 ? Constants.LINE_BREAK : "")
                    .append(projectionBreakdown.length() > 0 ? Constants.LINE_BREAK : "")
                    .append(projectionBreakdown)
                    .toString();
            proj.put(Constants.PLAYER_INFO, rankingSub);
            data.add(proj);

            Map<String, String> paa = new HashMap<>();
            paa.put(Constants.PLAYER_BASIC, "PAA: " + Constants.DECIMAL_FORMAT.format(player.getPaa()));
            int paaRank = getPaa(null, player.getPaa());
            int paaPos = getPaa(player.getPosition(), player.getPaa());
            String subRank = getRankingSub(paaRank, paaPos);
            if (player.getAuctionValueCustom(rankings) > 0.0) {
                subRank += Constants.LINE_BREAK + "PAA/$: " + Constants.DECIMAL_FORMAT.format(player.getPaa() / player.getAuctionValueCustom(rankings));
            }
            subRank += Constants.LINE_BREAK + "Scaled PAA: " + Constants.DECIMAL_FORMAT.format(player.getScaledPAA(rankings));
            paa.put(Constants.PLAYER_INFO, subRank);
            data.add(paa);

            Map<String, String> xVal = new HashMap<>();
            xVal.put(Constants.PLAYER_BASIC, "X Value: " + Constants.DECIMAL_FORMAT.format(player.getxVal()));
            int xValRank = getXVal(null, player.getxVal());
            int xValPos = getXVal(player.getPosition(), player.getxVal());
            String xValSub = getRankingSub(xValRank, xValPos);
            if (player.getAuctionValueCustom(rankings) > 0.0) {
                xValSub  += Constants.LINE_BREAK + "X Value/$: " + Constants.DECIMAL_FORMAT.format(player.getxVal() / player.getAuctionValueCustom(rankings));
            }
            xValSub += Constants.LINE_BREAK + "Scaled X Value: " + Constants.DECIMAL_FORMAT.format(player.getScaledXVal(rankings));
            xVal.put(Constants.PLAYER_INFO, xValSub);
            data.add(xVal);

            Map<String, String> voLS = new HashMap<>();
            voLS.put(Constants.PLAYER_BASIC, "VOLS: " + Constants.DECIMAL_FORMAT.format(player.getVOLS()));
            int voLSRank = getVoLSRank(null, player.getVOLS());
            int voLSPos = getVoLSRank(player.getPosition(), player.getVOLS());
            String voLSSub = getRankingSub(voLSRank, voLSPos);
            if (player.getAuctionValueCustom(rankings) > 0.0) {
                voLSSub += Constants.LINE_BREAK + "VOLS/$: " + Constants.DECIMAL_FORMAT.format(player.getVOLS() / player.getAuctionValueCustom(rankings));
            }
            voLSSub += Constants.LINE_BREAK + "Scaled VOLS: " + Constants.DECIMAL_FORMAT.format(player.getScaledVOLS(rankings));
            voLS.put(Constants.PLAYER_INFO, voLSSub);
            data.add(voLS);
        }

        if (!StringUtils.isBlank(player.getStats())) {
            Map<String, String> stats = new HashMap<>();
            stats.put(Constants.PLAYER_BASIC, Constants.LAST_YEAR_KEY + " Stats");
            stats.put(Constants.PLAYER_INFO, player.getStats());
            data.add(stats);
        }

        String lastUpdated = LocalSettingsHelper.getLastRankingsFetchedDate(this);
        if (!Constants.NOT_SET_KEY.equals(lastUpdated)) {
            Map<String, String> lastUpdatedMap = new HashMap<>();
            lastUpdatedMap.put(Constants.PLAYER_BASIC, "Rankings Freshness");
            lastUpdatedMap.put(Constants.PLAYER_INFO, "Last updated " + lastUpdated);
            data.add(lastUpdatedMap);
        }

        adapter.notifyDataSetChanged();
    }

    private void displayInfo() {
        data.clear();
        commentData.clear();
        commentList.setVisibility(View.GONE);
        infoList.setVisibility(View.VISIBLE);
        chipCloud.setVisibility(View.VISIBLE);
        infoList.setSelection(0);

        View ranks = findViewById(R.id.ranks_button_selected);
        View playerSelected = findViewById(R.id.player_info_button_selected);
        View teamInfo = findViewById(R.id.team_info_button_selected);
        View news = findViewById(R.id.news_button_selected);
        View comments = findViewById(R.id.comment_button_selected);
        findViewById(R.id.comment_input_base).setVisibility(View.GONE);
        ranks.setVisibility(View.INVISIBLE);
        playerSelected.setVisibility(View.VISIBLE);
        teamInfo.setVisibility(View.INVISIBLE);
        news.setVisibility(View.INVISIBLE);
        comments.setVisibility(View.INVISIBLE);

        Map<String, String> context = new HashMap<>();
        context.put(Constants.PLAYER_BASIC, "Current status");
        StringBuilder playerSub = new StringBuilder();
        if (rankings.isPlayerWatched(player.getUniqueId())) {
            playerSub.append("In your watch list").append(Constants.LINE_BREAK);
        }
        if (rankings.getDraft().isDrafted(player)) {
            if (rankings.getDraft().isDraftedByMe(player)) {
                playerSub.append("On your team");
            } else {
                playerSub.append("On another team");
            }
        } else {
            playerSub.append("Available")
                    .append(Constants.LINE_BREAK);

            if (rankings.getDraft().getMyPlayers().size() > 0) {
                // TODO: should this print more specific info? Names?
                List<Player> sameBye = rankings.getDraft().getPlayersWithSameBye(player, rankings);
                if (sameBye.size() > 1 || sameBye.size() == 0) {
                    playerSub.append("Same bye as ")
                            .append(sameBye.size())
                            .append(" players on your team");
                } else {
                    playerSub.append("Same bye as ")
                            .append(sameBye.size())
                            .append(" player on your team");
                }
                if (sameBye.size() > 0) {
                    // No sense printing that it's the same as no players AND no <position>s
                    playerSub.append(Constants.LINE_BREAK);
                    List<Player> sameByeAndPos = rankings.getDraft().getPlayersWithSameByeAndPos(player, rankings);
                    if (sameByeAndPos.size() > 1) {
                        playerSub.append("Same bye as ")
                                .append(sameByeAndPos.size())
                                .append(" ")
                                .append(player.getPosition())
                                .append("s on your team");
                    } else {
                        playerSub.append("Same bye as ")
                                .append(sameByeAndPos.size())
                                .append(" ")
                                .append(player.getPosition())
                                .append(" on your team");
                    }
                }
            }
        }
        String playerStatus = playerSub.toString();
        if (playerStatus.endsWith(Constants.LINE_BREAK)) {
            playerStatus = playerStatus.substring(0, playerStatus.length() - 1);
        }
        context.put(Constants.PLAYER_INFO, playerStatus);
        data.add(context);

        if (StringUtils.isBlank(rankings.getPlayerNote(player.getUniqueId()))) {
            Map<String, String> note = new HashMap<>();
            note.put(Constants.PLAYER_BASIC, Constants.DEFAULT_NOTE);
            note.put(Constants.PLAYER_INFO, Constants.NOTE_SUB);
            data.add(note);
        } else {
            Map<String, String> note = new HashMap<>();
            note.put(Constants.PLAYER_BASIC, rankings.getPlayerNote(player.getUniqueId()));
            note.put(Constants.PLAYER_INFO, Constants.NOTE_SUB);
            data.add(note);
        }

        Map<String, String> injury = new HashMap<>();
        injury.put(Constants.PLAYER_BASIC, "Player availability");
        if (!StringUtils.isBlank(player.getInjuryStatus())) {
            injury.put(Constants.PLAYER_INFO, player.getInjuryStatus());
        } else {
            injury.put(Constants.PLAYER_INFO, "Healthy");
        }
        data.add(injury);

        if (!Constants.DEFAULT_RANK.equals(player.getAdp())) {
            List<Player> nearbyPlayers = getPlayersDraftedNearby();
            Map<String, String> nearbyData = new HashMap<>();
            nearbyData.put(Constants.PLAYER_BASIC, "Players drafted nearby");
            StringBuilder nearbyString = new StringBuilder();
            for (Player nearPlayer : nearbyPlayers) {
                nearbyString = nearbyString
                        .append(nearPlayer.getAdp() < player.getAdp() ? "" : "+")
                        .append(
                            Constants.DECIMAL_FORMAT.format(nearPlayer.getAdp() - player.getAdp()))
                        .append(": ")
                        .append(nearPlayer.getName())
                        .append(" - ")
                        .append(nearPlayer.getPosition())
                        .append(", ")
                        .append(nearPlayer.getTeamName())
                        .append(Constants.LINE_BREAK);
            }
            nearbyData.put(Constants.PLAYER_INFO, nearbyString.toString());

            data.add(nearbyData);
        }

        if (viewCount > 0) {
            Map<String, String> activityData = new HashMap<>();
            activityData.put(Constants.PLAYER_BASIC, "Player popularity");
            String activityString = "" +
                    viewCount +
                    (viewCount > 1 ? " views" : " view") +
                    Constants.LINE_BREAK +
                    "In " +
                    watchCount +
                    (watchCount == 1 ? " watch list" : " watch lists") +
                    Constants.LINE_BREAK +
                    "Drafted " +
                    draftCount +
                    (draftCount == 1 ? " time" : " times");
            activityData.put(Constants.PLAYER_INFO, activityString);
            data.add(activityData);
        }

        adapter.notifyDataSetChanged();
    }

    private void displayTeam() {
        data.clear();
        commentData.clear();
        commentList.setVisibility(View.GONE);
        infoList.setVisibility(View.VISIBLE);
        chipCloud.setVisibility(View.GONE);
        infoList.setSelection(0);

        View ranks = findViewById(R.id.ranks_button_selected);
        View playerSelected = findViewById(R.id.player_info_button_selected);
        View teamInfo = findViewById(R.id.team_info_button_selected);
        View news = findViewById(R.id.news_button_selected);
        View comments = findViewById(R.id.comment_button_selected);
        findViewById(R.id.comment_input_base).setVisibility(View.GONE);
        ranks.setVisibility(View.INVISIBLE);
        playerSelected.setVisibility(View.INVISIBLE);
        teamInfo.setVisibility(View.VISIBLE);
        news.setVisibility(View.INVISIBLE);
        comments.setVisibility(View.INVISIBLE);

        Team team = rankings.getTeam(player);
        if (team == null || Constants.NO_TEAM.equals(player.getTeamName())) {
            Map<String, String> datum = new HashMap<>();
            datum.put(Constants.PLAYER_BASIC, "No info available for this team.");
            datum.put(Constants.PLAYER_INFO, "Please try another player, or refresh your rankings.");
            data.add(datum);
        } else {

            if (!StringUtils.isBlank(team.getDraftClass()) && team.getDraftClass().length() > 4) {
                Map<String, String> draft = new HashMap<>();
                draft.put(Constants.PLAYER_BASIC, "Draft recap");
                draft.put(Constants.PLAYER_INFO, team.getDraftClass());
                data.add(draft);
            } else {
                Log.d(TAG, "No draft class to display");
            }

            if (!StringUtils.isBlank(team.getFaClass()) && team.getFaClass().length() > 4) {
                Map<String, String> incomingFa = new HashMap<>();
                incomingFa.put(Constants.PLAYER_BASIC, "Incoming Players");
                incomingFa.put(Constants.PLAYER_INFO, team.getIncomingFA());
                data.add(incomingFa);

                Map<String, String> outgoingFa = new HashMap<>();
                outgoingFa.put(Constants.PLAYER_BASIC, "Outgoing Players");
                outgoingFa.put(Constants.PLAYER_INFO, team.getOutgoingFA());
                data.add(outgoingFa);
            } else {
                Log.d(TAG, "No FA class to display");
            }

            if (!StringUtils.isBlank(team.getoLineRanks()) && team.getoLineRanks().length() > 4) {
                Map<String, String> oline = new HashMap<>();
                oline.put(Constants.PLAYER_BASIC, "Offensive line grades");
                oline.put(Constants.PLAYER_INFO, team.getoLineRanks());
                data.add(oline);
            } else {
                Log.d(TAG, "No oline ranks to display");
            }

            Map<String, String> schedule = new HashMap<>();
            schedule.put(Constants.PLAYER_BASIC, Constants.YEAR_KEY + " schedule");
            schedule.put(Constants.PLAYER_INFO, team.getSchedule() + Constants.LINE_BREAK + Constants.LINE_BREAK
                    + "Positional SOS: " + team.getSosForPosition(player.getPosition()) + Constants.LINE_BREAK
                    + "1 is easiest, 32 hardest");
            data.add(schedule);
        }
        adapter.notifyDataSetChanged();
    }

    private void displayNews() {
        data.clear();
        commentData.clear();
        commentList.setVisibility(View.GONE);
        infoList.setVisibility(View.VISIBLE);
        chipCloud.setVisibility(View.GONE);
        infoList.setSelection(0);

        View ranks = findViewById(R.id.ranks_button_selected);
        View playerSelected = findViewById(R.id.player_info_button_selected);
        View team = findViewById(R.id.team_info_button_selected);
        View newsInfo = findViewById(R.id.news_button_selected);
        View comments = findViewById(R.id.comment_button_selected);
        findViewById(R.id.comment_input_base).setVisibility(View.GONE);
        ranks.setVisibility(View.INVISIBLE);
        playerSelected.setVisibility(View.INVISIBLE);
        team.setVisibility(View.INVISIBLE);
        newsInfo.setVisibility(View.VISIBLE);
        comments.setVisibility(View.INVISIBLE);

        if (playerNews == null || playerNews.isEmpty()) {
            Map<String, String> news = new HashMap<>();
            news.put(Constants.PLAYER_BASIC, "No news available for this player");
            news.put(Constants.PLAYER_INFO, "Try a different player, or ensure you have a valid internet connection");
            data.add(news);
        } else {
            for (PlayerNews newsItem : playerNews) {
                Map<String, String> news = new HashMap<>();
                news.put(Constants.PLAYER_BASIC, newsItem.getNews());
                news.put(Constants.PLAYER_INFO, newsItem.getImpact());
                data.add(news);
            }
        }
        adapter.notifyDataSetChanged();
    }

    private void displayComments() {
        data.clear();
        commentData.clear();
        commentList.setVisibility(View.VISIBLE);
        infoList.setVisibility(View.GONE);
        chipCloud.setVisibility(View.GONE);
        if (doUpdateImage) {
            ((ImageButton) findViewById(R.id.player_info_comments)).setImageResource(R.drawable.comment_white);
            doUpdateImage = false;
        }
        commentList.setSelection(0);

        View ranks = findViewById(R.id.ranks_button_selected);
        View playerSelected = findViewById(R.id.player_info_button_selected);
        View team = findViewById(R.id.team_info_button_selected);
        View newsInfo = findViewById(R.id.news_button_selected);
        View commentsView = findViewById(R.id.comment_button_selected);
        findViewById(R.id.comment_input_base).setVisibility(View.VISIBLE);
        ranks.setVisibility(View.INVISIBLE);
        playerSelected.setVisibility(View.INVISIBLE);
        team.setVisibility(View.INVISIBLE);
        newsInfo.setVisibility(View.INVISIBLE);
        commentsView.setVisibility(View.VISIBLE);

        for (Comment comment : comments) {
            commentData.add(getCommentDatum(comment));
        }
        if (comments.size() == 0) {
            Map<String, String> emptyMap = new HashMap<>();
            emptyMap.put(Constants.COMMENT_CONTENT, "No comments exist for this player. Be the first to post!");
            commentData.add(emptyMap);
        }

        boolean moreFound = false;
        Set<String> seenComments = new HashSet<>();
        do {
            moreFound = false;
            for (int i = 0; i < commentData.size(); i++) {
                Map<String, String> datum = commentData.get(i);
                String commentId = datum.get(Constants.COMMENT_ID);
                if (replyMap.containsKey(commentId) && !seenComments.contains(commentId)) {
                    seenComments.add(commentId);
                    moreFound = true;
                    List<Comment> replies = replyMap.get(commentId);
                    int newIndex = i + 1;
                    for (Comment comment : replies) {
                        commentData.add(newIndex++, getCommentDatum(comment));
                    }
                }
            }
        } while (moreFound);

        final EditText input = findViewById(R.id.player_info_comment_input);
        final ImageButton submit = findViewById(R.id.player_info_comment_submit);
        final Activity activity = this;
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String commentContent = input.getText().toString();
                if (!StringUtils.isBlank(commentContent)) {
                    input.setText("");
                    AppSyncHelper.createComment(activity, commentContent, player.getUniqueId(), replyId, replyDepth);
                    GeneralUtils.hideKeyboard(activity);
                }
            }
        });
        input.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                input.setText("");
                resetReplyContext();
                GeneralUtils.hideKeyboard(activity);
                return true;
            }
        });

        commentAdapter.notifyDataSetChanged();
    }

    private Map<String, String> getCommentDatum(Comment comment) {
        Map<String, String> commentMap = new HashMap<>();
        commentMap.put(Constants.COMMENT_AUTHOR, comment.getAuthor());
        commentMap.put(Constants.COMMENT_CONTENT, comment.getContent());
        commentMap.put(Constants.COMMENT_TIMESTAMP, comment.getTime());
        commentMap.put(Constants.COMMENT_ID, comment.getId());
        commentMap.put(Constants.COMMENT_REPLY_DEPTH, String.valueOf(comment.getReplyDepth()));
        commentMap.put(Constants.COMMENT_REPLY_ID, comment.getReplyToId());
        commentMap.put(Constants.COMMENT_UPVOTE_COUNT, String.valueOf(comment.getUpvotes()));
        commentMap.put(Constants.COMMENT_DOWNVOTE_COUNT, String.valueOf(comment.getDownvotes()));
        if (comment.isUpvoted()) {
            commentMap.put(Constants.COMMENT_UPVOTE_IMAGE, Integer.toString(R.drawable.upvoted));
            commentMap.put(Constants.COMMENT_DOWNVOTE_IMAGE, Integer.toString(R.drawable.not_downvoted));
        } else if (comment.isDownvoted()) {
            commentMap.put(Constants.COMMENT_UPVOTE_IMAGE, Integer.toString(R.drawable.not_upvoted));
            commentMap.put(Constants.COMMENT_DOWNVOTE_IMAGE, Integer.toString(R.drawable.downvoted));
        } else {
            commentMap.put(Constants.COMMENT_UPVOTE_IMAGE, Integer.toString(R.drawable.not_upvoted));
            commentMap.put(Constants.COMMENT_DOWNVOTE_IMAGE, Integer.toString(R.drawable.not_downvoted));
        }
        return commentMap;
    }

    public void updateReplyContext(int replyDepth, String replyId, String newHint) {
        this.replyId = replyId;
        this.replyDepth = replyDepth;
        final EditText input = findViewById(R.id.player_info_comment_input);
        input.setHint(newHint);
    }

    private void resetReplyContext() {
        updateReplyContext(0, Constants.COMMENT_NO_REPLY_ID, "Comment");
    }

    public void conditionallyUpvoteComment(String commentId) {
        Comment domainComment = null;
        for (Comment comment : comments) {
            if (comment.getId().equals(commentId)) {
                domainComment = comment;
                break;
            }
        }
        for (Map<String, String> datum : commentData) {
            if (datum.get(Constants.COMMENT_ID).equals(commentId) && !domainComment.isUpvoted()) {
                datum.put(Constants.COMMENT_UPVOTE_IMAGE, Integer.toString(R.drawable.upvoted));
                datum.put(Constants.COMMENT_DOWNVOTE_IMAGE, Integer.toString(R.drawable.not_downvoted));
                if (domainComment.isDownvoted()) {
                    int downvotes = Integer.parseInt(datum.get(Constants.COMMENT_DOWNVOTE_COUNT));
                    datum.put(Constants.COMMENT_DOWNVOTE_COUNT, String.valueOf(--downvotes));
                }
                int upvotes = Integer.parseInt(datum.get(Constants.COMMENT_UPVOTE_COUNT));
                datum.put(Constants.COMMENT_UPVOTE_COUNT, String.valueOf(++upvotes));
                commentAdapter.notifyDataSetChanged();
                AppSyncHelper.upvoteComment(this, commentId, domainComment.isDownvoted());
                domainComment.setUpvoted(true);
                domainComment.setDownvoted(false);
                break;
            }
        }
    }

    public void conditionallyDownvoteComment(String commentId) {
        Comment domainComment = null;
        for (Comment comment : comments) {
            if (comment.getId().equals(commentId)) {
                domainComment = comment;
                break;
            }
        }
        for (Map<String, String> datum : commentData) {
            if (datum.get(Constants.COMMENT_ID).equals(commentId) && !domainComment.isDownvoted()) {
                datum.put(Constants.COMMENT_UPVOTE_IMAGE, Integer.toString(R.drawable.not_upvoted));
                datum.put(Constants.COMMENT_DOWNVOTE_IMAGE, Integer.toString(R.drawable.downvoted));
                if (domainComment.isUpvoted()) {
                    int upvotes = Integer.parseInt(datum.get(Constants.COMMENT_UPVOTE_COUNT));
                    datum.put(Constants.COMMENT_UPVOTE_COUNT, String.valueOf(--upvotes));
                }
                int downvotes = Integer.parseInt(datum.get(Constants.COMMENT_DOWNVOTE_COUNT));
                datum.put(Constants.COMMENT_DOWNVOTE_COUNT, String.valueOf(++downvotes));
                commentAdapter.notifyDataSetChanged();
                AppSyncHelper.downvoteComment(this, commentId, domainComment.isUpvoted());
                domainComment.setUpvoted(false);
                domainComment.setDownvoted(true);
                break;
            }
        }
    }


    public void updateVoteCount(String commentId, int upvotes, int downvotes) {
        for (Map<String, String> comment : commentData) {
            if (comment.get(Constants.COMMENT_ID).equals(commentId)) {
                comment.put(Constants.COMMENT_UPVOTE_COUNT, String.valueOf(upvotes));
                comment.put(Constants.COMMENT_DOWNVOTE_COUNT, String.valueOf(downvotes));
                commentAdapter.notifyDataSetChanged();
                break;
            }
        }
    }

    public void populateNews(List<PlayerNews> fetchedNews) {
        this.playerNews = fetchedNews;
        View newsView = findViewById(R.id.news_button_selected);
        if (View.VISIBLE == newsView.getVisibility()) {
            displayNews();
        }
    }

    public void addComments(List<Comment> comments, String nextToken) {
        List<Comment> newComments = new ArrayList<>();
        int maxDepth = 0;
        for (Comment comment : comments) {
            if (comment.getReplyDepth() > maxDepth) {
                maxDepth = comment.getReplyDepth();
            }
            if (comment.getReplyDepth() > 0) {
                if (replyMap.containsKey(comment.getReplyToId())) {
                    replyMap.get(comment.getReplyToId()).add(comment);
                } else {
                    List<Comment> repliesList = new ArrayList<>();
                    repliesList.add(comment);
                    replyMap.put(comment.getReplyToId(), repliesList);
                }
            } else {
                newComments.add(comment);
            }
        }
        this.comments.addAll(newComments);
        if (sortByUpvotes) {
            Collections.sort(this.comments,new Comparator<Comment>() {
                @Override
                public int compare(Comment a, Comment b) {
                    return b.getUpvotes().compareTo(a.getUpvotes());
                }
            });
            for (List<Comment> replies : replyMap.values()) {
                Collections.sort(replies,new Comparator<Comment>() {
                    @Override
                    public int compare(Comment a, Comment b) {
                        return b.getUpvotes().compareTo(a.getUpvotes());
                    }
                });
            }
        }

        View commentsView = findViewById(R.id.comment_button_selected);
        if (View.VISIBLE == commentsView.getVisibility()) {
            displayComments();
        }

        if (comments.size() > LocalSettingsHelper.getNumberOfCommentsOnPlayer(this, player.getUniqueId())) {
            ((ImageButton)findViewById(R.id.player_info_comments)).setImageResource(R.drawable.new_comment_white);
            doUpdateImage = true;
            LocalSettingsHelper.setNumberOfCommentsOnPlayer(this, player.getUniqueId(), comments.size());
        }

        if (!StringUtils.isBlank(nextToken)) {
            AppSyncHelper.getCommentsForPlayer(this, player.getUniqueId(), nextToken, sortByUpvotes);
        }
    }

    public void giveCommentInputFocus() {
        InputMethodManager imm = (InputMethodManager)   getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);
    }

    private String getLeverage() {
        return "Leverage: " +
                ParseMath.getLeverage(player, rankings);
    }

    private String getRankingSub(int rank, int posRank) {
        return "Ranked " +
                posRank +
                " positionally, " +
                rank +
                " overall";
    }

    private int getEcr(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getEcr() < source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getAdp(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getAdp() < source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getDynasty(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getDynastyRank() < source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getBestBall(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getBestBallRank() < source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getRookie(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getRookieRank() < source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getAuc(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getAuctionValue() > source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getProj(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getProjection() > source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getPaa(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getPaa() > source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getXVal(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getxVal() > source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private int getVoLSRank(String pos, double source) {
        int rank = 1;
        for (String key : rankings.getPlayers().keySet()) {
            Player player = rankings.getPlayer(key);
            if (pos == null || pos.equals(player.getPosition())) {
                if (player.getVOLS() > source) {
                    rank++;
                }
            }
        }
        return rank;
    }

    private List<Player> getPlayersDraftedNearby() {

        // First, sort all players by nearest adp to player
        Comparator<Player> comparator =  new Comparator<Player>() {
            @Override
            public int compare(Player a, Player b) {
                int diffA = Math.abs((int)(a.getAdp() - player.getAdp()));
                int diffB = Math.abs((int)(b.getAdp() - player.getAdp()));
                if (diffA > diffB) {
                    return 1;
                }
                if (diffA < diffB) {
                    return -1;
                }
                return 0;
            }
        };
        List<Player> allPlayers = new ArrayList<>();
        allPlayers.addAll(rankings.getPlayers().values());
        Collections.sort(allPlayers, comparator);

        // Next, we want to get the x nearest, instead of hundreds.
        int listSize = 0;
        List<Player> nearestPlayers = new ArrayList<>();
        for (int i = 0; i < allPlayers.size(); i++) {
            Player possiblePlayer = allPlayers.get(i);
            if (listSize == MAX_NEARBY_PLAYERS) {
                break;
            } else if (possiblePlayer.getUniqueId().equals(player.getUniqueId()) ||
                !rankings.getLeagueSettings().getRosterSettings().isPositionValid(possiblePlayer.getPosition())) {
                continue;
            }
            nearestPlayers.add(possiblePlayer);
            listSize++;
        }

        // Finally, we want to sort these by adp overall.
        Comparator<Player> adpComparator =  new Comparator<Player>() {
            @Override
            public int compare(Player a, Player b) {
                if (a.getAdp() > b.getAdp()) {
                    return 1;
                }
                if (a.getAdp() < b.getAdp()) {
                    return -1;
                }
                return 0;
            }
        };
        Collections.sort(nearestPlayers, adpComparator);
        return nearestPlayers;
    }
}
